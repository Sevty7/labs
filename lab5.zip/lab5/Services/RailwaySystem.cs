﻿using System.Xml.Serialization;
using lab5.Entities.Carriages;
using lab5.Entities.Trains;

namespace lab5.Services
{
    public class RailwaySystem : IPassengerService, IAdminService
    {
        private List<Train> _trains = new List<Train>();


        //Admin
        private Train GetTrainByNumber(string trainNumber)
        {
            var train = _trains.Find(t => t.TrainNumber == trainNumber);
            if (train == null)
            {
                throw new KeyNotFoundException($"Train with number {trainNumber} not found.");
            }
            return train;
        }

        private void CreateTrain(string number) 
        {
            CreateTrain(number, "Default Route", true);
        }
        private void CreateTrain(string number, string route, bool isPassenger)
        {
            if (_trains.Any(t => t.TrainNumber == number))
            {
                throw new InvalidOperationException($"Train with number {number} already exists.");
            }

            Train newTrain = isPassenger
                ? new PassengerTrain(number, route)
                : new FreightTrain(number, route);

            _trains.Add(newTrain);
        }


        private void AddCarriageToTrain(string trainNumber, Carriage carriage)
        {
            var train = GetTrainByNumber(trainNumber);
            train.AddCarriage(carriage);
        }

        private void RemoveCarriageFromTrain(string trainNumber, int index)
        {
            var train = GetTrainByNumber(trainNumber);
            train.RemoveCarriage(index);
        }

        public void SaveSystemState(string filePath) 
        {
            if (string.IsNullOrWhiteSpace(filePath))
                throw new ArgumentException("File path is null or empty.", nameof(filePath));

            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(RailwaySystem));
                using (StreamWriter sw = new StreamWriter(filePath))
                {
                    serializer.Serialize(sw, this);
                }
            }
            catch (InvalidOperationException e)
            {
                throw new InvalidOperationException("Failed to serialize RailwaySystem to XML.", e);
            }
        }

        private static RailwaySystem LoadTrainsFromXml(string filePath)
        {
            if (string.IsNullOrWhiteSpace(filePath))
                throw new ArgumentException("File path is null or empty.", nameof(filePath));

            if (!File.Exists(filePath))
                throw new FileNotFoundException($"File not found: {filePath}", filePath);

            try
            {
                XmlSerializer deSerializer = new XmlSerializer(typeof(RailwaySystem));
                using (StreamReader sr = new StreamReader(filePath))
                {
                    var obj = deSerializer.Deserialize(sr);
                    if (obj is RailwaySystem)
                        return (RailwaySystem)obj;
                    else
                        throw new InvalidDataException("XML file does not contain RailwaySystem data.");
                }
            }
            catch (InvalidOperationException e)
            {
                throw new InvalidOperationException("Failed to deserialize XML to RailwaySystem.", e);
            }
        }


        public List<Train> GetAllTrains()
        {
            return new List<Train>();
        }

        public bool IsTrainOverloaded(string trainNumber) { return false; }





        //Passenger
        public List<Train> GetAvailableTrains()
        {
            return new List<Train>();
        }

        public void BuyTicket(Train train, int carriageIndex) 
        {
            
        }

        public Dictionary<string, decimal> GetDiningMenu(string trainNumber)
        {
            return new Dictionary<string, decimal>();
        }
    }
}
