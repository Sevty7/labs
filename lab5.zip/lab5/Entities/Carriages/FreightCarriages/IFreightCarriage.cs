﻿namespace lab5.Entities.Carriages.FreightCarriages
{
    public interface IFreightCarriage
    {
        double CurrentLoad { get; set; }
    }
}
