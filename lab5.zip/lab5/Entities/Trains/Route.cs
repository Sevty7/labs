﻿namespace lab5.Entities.Trains
{
    public class Route
    {

    }
}
